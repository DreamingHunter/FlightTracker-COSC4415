import java.awt.Color;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class TrackerUI extends JFrame implements ActionListener{
	
	//Text Field
	String fname, lname, dob, dest, ori;
	
	JButton bookFlight;
	JTextField firstName, lastName, dateOfBirth, destination, origin;
	
	TrackerUI() {
		
		// Images
		
		ImageIcon image = new ImageIcon("planelogo.png"); 
		ImageIcon map = new ImageIcon("map.png"); 
		
		bookFlight = new JButton();
		bookFlight.setText("Book A Flight");
		bookFlight.setPreferredSize(new Dimension(250,40));
		bookFlight.addActionListener(this);
		
		//Labels. 
		
		JLabel label = new JLabel();
		label.setText("PROJECT AIRLINES"); 
		label.setIcon(image);
		label.setFont(new Font("Constantia", Font.BOLD, 36));
		label.setForeground(Color.white);
		
		
		JLabel mapThing = new JLabel();
		mapThing.setText(null);
		mapThing.setBounds(400, 300, 300, 300);
		mapThing.setIcon(map); 
		
		JLabel titleTicket = new JLabel();
		titleTicket.setText("BOOK A FLIGHT"); 
		titleTicket.setFont(new Font("Constantia", Font.PLAIN, 25));
		
		
		//Panels 
		
		JPanel namePlate = new JPanel();
		namePlate.setBackground(new Color(174,160,138));
		namePlate.setPreferredSize(new Dimension(100,50)); 
		
		JPanel formHolder = new JPanel(); //Contains the form bar.
		formHolder.setPreferredSize(new Dimension(300,300));
		
		JPanel mapImage = new JPanel();
		mapImage.setPreferredSize(new Dimension(100,100));
		
		//TextFields
		
		firstName = new JTextField();
		lastName = new JTextField();
		dateOfBirth = new JTextField();
		destination = new JTextField();
		origin = new JTextField();
		
		firstName.setPreferredSize(new Dimension(250,40));
		lastName.setPreferredSize(new Dimension(250,40));
		dateOfBirth.setPreferredSize(new Dimension(250,40));
		destination.setPreferredSize(new Dimension(250,40));
		origin.setPreferredSize(new Dimension(250,40));
		
		//Frame Settings
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(1920,1080);
		this.setLayout(new BorderLayout(10, 10));
		this.setVisible(true);
		

		this.add(namePlate, BorderLayout.NORTH);
		this.add(formHolder, BorderLayout.WEST);
		this.add(mapImage, BorderLayout.CENTER); 
		
		
		namePlate.add(label);
		mapImage.add(mapThing);
		formHolder.add(titleTicket);
		formHolder.add(firstName);
		formHolder.add(lastName);
		formHolder.add(dateOfBirth);
		
		formHolder.add(destination);
		formHolder.add(origin);
		formHolder.add(bookFlight);
	}
	


	@Override
	public void actionPerformed(ActionEvent e) { 
		// call method that passes information from text field to jdbc
		// Pop up that displays information. 
		
		if(e.getSource()==bookFlight) {
			fname = firstName.getText(); 
			lname = lastName.getText();
			dob = dateOfBirth.getText(); 
			dest = destination.getText(); 
			ori = origin.getText(); 
			
			//Replace with method that sends information to JDBC. User sees pop up that tells em if the information is good or not. If good repeats information. If not show error. 
			JOptionPane.showMessageDialog(bookFlight, "Name: " + fname + "" + lname + "\n DOB:" + dob, "Ticket Placed\n" + "From " + dest + "to " + ori + ".", JOptionPane.PLAIN_MESSAGE);
		}
		
	
	}
	
	
	
}



